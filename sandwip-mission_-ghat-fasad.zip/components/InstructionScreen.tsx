
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { BENGALI_STRINGS } from '../constants';
import { BookOpen, ChevronRight, Play, ShieldAlert, Heart, Wind } from 'lucide-react';
import { audio } from '../audioUtils';

interface InstructionScreenProps {
  onNext: () => void;
}

export const InstructionScreen: React.FC<InstructionScreenProps> = ({ onNext }) => {
  const statIcons = [
    <Wind className="w-10 h-10 text-emerald-400" />,
    <Heart className="w-10 h-10 text-purple-400" />,
    <ShieldAlert className="w-10 h-10 text-red-400" />
  ];

  useEffect(() => {
    // Narrate the core vision when the rules screen opens
    audio.speak(BENGALI_STRINGS.instructions.title + ". " + BENGALI_STRINGS.instructions.core_vision, "system");
  }, []);

  return (
    <div className="h-screen w-full bg-[#020617] flex items-center justify-center p-6 overflow-hidden relative">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-600/10 via-slate-950 to-black pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-blue-500/10 blur-[150px] rounded-full animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-indigo-500/10 blur-[150px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
      </div>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-6xl bg-slate-900/60 backdrop-blur-3xl border border-blue-500/20 rounded-[4rem] p-12 md:p-20 shadow-[0_0_150px_rgba(30,64,175,0.3)] flex flex-col gap-12 overflow-y-auto max-h-[92vh]"
      >
        <div className="border-b border-blue-500/20 pb-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-8">
            <div className="bg-blue-600/20 p-6 rounded-3xl border border-blue-500/40 shadow-inner">
              <BookOpen className="text-blue-400 w-12 h-12" />
            </div>
            <div>
              <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter leading-none">
                {BENGALI_STRINGS.instructions.title}
              </h2>
              <p className="text-blue-400/60 font-black uppercase tracking-[0.5em] text-sm mt-3">Mission Survival Protocol</p>
            </div>
          </div>
          <span className="text-sm font-black text-blue-100 uppercase tracking-widest bg-blue-600/30 border border-blue-500/50 px-8 py-3 rounded-full shadow-xl">
            Read Carefully
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BENGALI_STRINGS.instructions.stats.map((stat, idx) => (
            <motion.div 
              key={idx} 
              whileHover={{ y: -10, backgroundColor: "rgba(30, 41, 59, 0.5)" }}
              className="bg-black/40 p-10 rounded-[3rem] border border-blue-500/10 flex flex-col items-center text-center gap-6 transition-all shadow-2xl"
            >
              <div className="bg-slate-900/80 p-5 rounded-2xl shadow-inner border border-white/5">{statIcons[idx]}</div>
              <h3 className="text-3xl font-black text-white uppercase tracking-wider">
                {stat.label}
              </h3>
              <p className="text-lg text-blue-100/70 leading-relaxed font-semibold">
                {stat.desc}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          {BENGALI_STRINGS.instructions.levels.map((level, idx) => (
            <div key={idx} className="flex flex-col gap-4 p-8 rounded-[2.5rem] bg-slate-900/80 border border-white/5 shadow-xl">
              <div className="flex items-center gap-4">
                <span className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg font-black shadow-lg">
                  {idx + 1}
                </span>
                <h4 className="text-xl font-black text-white uppercase tracking-tight">{level.title}</h4>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed font-medium italic">{level.desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-blue-950/40 border border-blue-500/30 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
          <div className="absolute top-0 left-0 w-3 h-full bg-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.5)]" />
           <p className="text-blue-50 text-xl md:text-3xl italic text-center font-black leading-relaxed relative z-10 tracking-tight">
             "{BENGALI_STRINGS.instructions.core_vision}"
           </p>
        </div>

        <div className="flex justify-center pt-8">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            animate={{ 
              boxShadow: ["0 0 0px rgba(59,130,246,0)", "0 0 50px rgba(59,130,246,0.4)", "0 0 0px rgba(59,130,246,0)"] 
            }}
            transition={{ repeat: Infinity, duration: 2 }}
            onClick={onNext}
            className="w-full max-w-2xl py-8 bg-white text-black font-black rounded-[2.5rem] hover:bg-blue-50 transition-all uppercase tracking-[0.4em] flex items-center justify-center gap-6 text-3xl border-b-[12px] border-slate-300 shadow-2xl"
          >
            <Play className="fill-current w-10 h-10" />
            <span>{BENGALI_STRINGS.start_game}</span>
            <ChevronRight className="w-10 h-10" />
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
};
