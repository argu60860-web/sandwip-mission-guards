
import React from 'react';
import { PlayerStats } from '../types';
import { BENGALI_STRINGS, ICON_MAP } from '../constants';
import { motion } from 'framer-motion';
import { Home, Ticket, Footprints, Ship, Check } from 'lucide-react';

interface HUDProps {
  stats: PlayerStats;
  timer: number;
  levelName: string;
  onHome: () => void;
  disableHome?: boolean;
  showStats?: boolean;
  level?: number; // 1, 2, or 3
}

const JourneyTracker: React.FC<{ currentLevel: number }> = ({ currentLevel }) => {
  const levels = [
    { icon: <Ticket size={14} />, label: "Ticket" },
    { icon: <Footprints size={14} />, label: "Boarding" },
    { icon: <Ship size={14} />, label: "Sea" }
  ];

  return (
    <div className="flex items-center gap-4 bg-white/5 backdrop-blur-2xl border border-white/10 px-6 py-3 rounded-2xl">
      {levels.map((lvl, idx) => {
        const stageNum = idx + 1;
        const isActive = stageNum === currentLevel;
        const isCompleted = stageNum < currentLevel;

        return (
          <React.Fragment key={idx}>
            <div className="flex flex-col items-center gap-1 relative">
              <motion.div 
                animate={isActive ? { 
                  scale: [1, 1.15, 1],
                  borderColor: ["rgba(255,255,255,0.1)", "rgba(255,255,255,0.8)", "rgba(255,255,255,0.1)"],
                  boxShadow: ["0 0 0px rgba(255,255,255,0)", "0 0 20px rgba(255,255,255,0.2)", "0 0 0px rgba(255,255,255,0)"]
                } : {}}
                transition={{ repeat: Infinity, duration: 2 }}
                className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-700 ${
                  isActive ? 'bg-white text-black border-white' : 
                  isCompleted ? 'bg-gradient-to-br from-green-500 to-emerald-700 border-green-400 text-white' : 
                  'bg-stone-900/50 border-white/5 text-stone-600'
                }`}
              >
                {isCompleted ? <Check size={16} strokeWidth={4} /> : lvl.icon}
              </motion.div>
              <span className={`text-[8px] font-black uppercase tracking-[0.2em] ${isActive ? 'text-white' : 'text-stone-600'}`}>
                {lvl.label}
              </span>
            </div>
            {idx < levels.length - 1 && (
              <div className={`w-8 h-[2px] rounded-full mb-4 ${isCompleted ? 'bg-green-500' : 'bg-white/5'}`} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export const HUD: React.FC<HUDProps> = ({ stats, timer, levelName, onHome, disableHome, showStats = true, level = 0 }) => {
  return (
    <div className="fixed top-0 left-0 w-full p-6 z-[100] flex flex-col md:flex-row justify-between items-start pointer-events-none">
      <div className="flex flex-col gap-4 w-full md:w-96 pointer-events-auto">
        <div className="flex items-center gap-3">
          <motion.button 
            whileHover={!disableHome ? { scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" } : {}}
            whileTap={!disableHome ? { scale: 0.95 } : {}}
            onClick={onHome}
            disabled={disableHome}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all shadow-2xl ${
              disableHome 
                ? 'bg-black/40 border-white/5 text-stone-800 opacity-30' 
                : 'bg-black/60 backdrop-blur-xl border-white/10 text-white'
            }`}
          >
            <Home size={22} />
          </motion.button>
          
          {showStats && level > 0 && <JourneyTracker currentLevel={level} />}
        </div>

        {showStats && (
          <motion.div 
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="bg-stone-950/80 backdrop-blur-3xl border border-white/10 p-6 rounded-[2rem] space-y-5 shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
          >
            {/* Stamina Meter */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[9px] uppercase font-black tracking-widest text-stone-500">
                <span className="flex items-center gap-2">{ICON_MAP.STAMINA} {BENGALI_STRINGS.stamina}</span>
                <span className={stats.stamina < 30 ? "text-red-500" : "text-white"}>{Math.floor(stats.stamina)}%</span>
              </div>
              <div className="h-1.5 bg-black/50 rounded-full overflow-hidden p-[1px]">
                <motion.div 
                  className="h-full bg-gradient-to-r from-emerald-600 via-green-400 to-emerald-600 rounded-full" 
                  animate={{ width: `${stats.stamina}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>

            {/* Fear Meter */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[9px] uppercase font-black tracking-widest text-stone-500">
                <span className="flex items-center gap-2">{ICON_MAP.FEAR} {BENGALI_STRINGS.fear}</span>
                <span className={stats.fear > 70 ? "text-purple-500" : "text-white"}>{Math.floor(stats.fear)}%</span>
              </div>
              <div className="h-1.5 bg-black/50 rounded-full overflow-hidden p-[1px]">
                <motion.div 
                  className="h-full bg-gradient-to-r from-purple-600 via-indigo-400 to-purple-600 rounded-full" 
                  animate={{ width: `${stats.fear}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>

            {/* Frustration Meter */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[9px] uppercase font-black tracking-widest text-stone-500">
                <span className="flex items-center gap-2">{ICON_MAP.FRUSTRATION} {BENGALI_STRINGS.frustration}</span>
                <span className={stats.frustration > 70 ? "text-red-500" : "text-white"}>{Math.floor(stats.frustration)}%</span>
              </div>
              <div className="h-1.5 bg-black/50 rounded-full overflow-hidden p-[1px]">
                <motion.div 
                  className="h-full bg-gradient-to-r from-red-600 via-orange-400 to-red-600 rounded-full" 
                  animate={{ width: `${stats.frustration}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {showStats && (
        <div className="mt-4 md:mt-0 bg-white/5 backdrop-blur-2xl border border-white/10 px-8 py-4 rounded-2xl flex items-center gap-6 shadow-2xl pointer-events-auto">
          <div className="flex flex-col items-end">
            <span className="text-stone-500 text-[10px] font-black uppercase tracking-widest mb-1">Mission Clock</span>
            <span className={`text-3xl font-mono font-black tabular-nums tracking-tighter ${timer < 10 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
              {timer.toFixed(1)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
