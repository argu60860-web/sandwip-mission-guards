
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PlayerStats } from '../types';
import { BENGALI_STRINGS, LEVEL_TIMEOUTS } from '../constants';
import { AlertTriangle, Siren, Users, Ticket, MessageCircle } from 'lucide-react';
import { audio, CharacterRole } from '../audioUtils';

const RainCanvas: React.FC<{ intensity: number }> = ({ intensity }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let w = (canvas.width = window.innerWidth);
    let h = (canvas.height = window.innerHeight);

    const particles: any[] = [];
    const maxParticles = 400;

    const createParticle = () => {
      return {
        x: Math.random() * w,
        y: Math.random() * h - h,
        length: Math.random() * 20 + 10,
        speed: Math.random() * 20 + 15,
        opacity: Math.random() * 0.4 + 0.1,
        width: Math.random() * 1.5 + 0.5,
        wind: (Math.random() - 0.5) * 2 + 3,
      };
    };

    for (let i = 0; i < maxParticles; i++) {
      particles.push(createParticle());
    }

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const activeCount = Math.floor(maxParticles * intensity);

      for (let i = 0; i < activeCount; i++) {
        const p = particles[i];
        ctx.beginPath();
        ctx.strokeStyle = `rgba(174, 194, 224, ${p.opacity})`;
        ctx.lineWidth = p.width;
        ctx.lineCap = 'round';
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.wind, p.y + p.length);
        ctx.stroke();

        p.y += p.speed;
        p.x += p.wind;

        if (p.y > h) {
          if (Math.random() < intensity) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(255, 255, 255, ${p.opacity * 0.5})`;
            ctx.arc(p.x, h - Math.random() * 50, Math.random() * 3, 0, Math.PI, true);
            ctx.stroke();
          }
          p.y = -p.length;
          p.x = Math.random() * w;
        }
      }
      animationFrameId = requestAnimationFrame(draw);
    };

    const handleResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [intensity]);

  return <canvas ref={canvasRef} className="absolute inset-0 z-20 pointer-events-none" />;
};

const DynamicCrowd: React.FC<{ isVipPassing: boolean; rainIntensity: number }> = ({ isVipPassing, rainIntensity }) => {
  const crowdCount = 120;
  const crowdElements = useMemo(() => 
    Array.from({ length: crowdCount }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: 10 + Math.random() * 80,
      scale: 0.5 + Math.random() * 0.5,
      delay: Math.random() * 2,
      color: i % 3 === 0 ? 'bg-slate-800' : i % 3 === 1 ? 'bg-slate-700' : 'bg-slate-900',
    })), []);

  return (
    <div className="absolute inset-0 overflow-hidden opacity-30 pointer-events-none z-10">
      {crowdElements.map((p) => (
        <motion.div
          key={p.id}
          className="absolute"
          initial={{ left: `${p.x}%`, top: `${p.y}%` }}
          animate={{
            left: isVipPassing ? [`${p.x}%`, `${p.x + (p.x > 50 ? 10 : -10)}%`, `${p.x}%`] : `${p.x}%`,
            top: isVipPassing ? [`${p.y}%`, `${p.y + (Math.random() * 5 - 2.5)}%`, `${p.y}%`] : `${p.y}%`,
            scale: isVipPassing ? p.scale * 1.1 : p.scale,
            filter: `blur(${rainIntensity * 1.2}px)`,
          }}
          transition={{
            duration: isVipPassing ? 0.3 : 3,
            repeat: isVipPassing ? 6 : Infinity,
            repeatType: "reverse",
            delay: p.delay,
          }}
        >
          <div className={`w-8 h-12 rounded-t-full ${p.color} transition-colors duration-500`} />
        </motion.div>
      ))}
    </div>
  );
};

interface Level1Props {
  onComplete: (stats: PlayerStats, bribe: boolean) => void;
  onFail: () => void;
  updateGlobalStats: (stats: PlayerStats) => void;
  initialStats: PlayerStats;
}

export const Level1: React.FC<Level1Props> = ({ onComplete, onFail, updateGlobalStats, initialStats }) => {
  const [playerPosition, setPlayerPosition] = useState(0);
  const [timer, setTimer] = useState(LEVEL_TIMEOUTS.LEVEL_1);
  const [stats, setStats] = useState<PlayerStats>(initialStats);
  const [isVipPassing, setIsVipPassing] = useState(false);
  const [announcement, setAnnouncement] = useState("");
  const [speakerType, setSpeakerType] = useState<CharacterRole>("passenger_male");
  const [rainIntensity, setRainIntensity] = useState(0.4);
  const [isWrongLine, setIsWrongLine] = useState(false);

  useEffect(() => {
    // Intro narration
    audio.speak(BENGALI_STRINGS.level_intros.level1, "system");
  }, []);

  const handleMove = useCallback(() => {
    if (isVipPassing) {
       setStats(prev => ({ ...prev, frustration: Math.min(100, prev.frustration + 3) }));
       return;
    }
    
    setStats(prev => ({
      ...prev,
      stamina: Math.max(0, prev.stamina - (isWrongLine ? 1.0 : 0.25)),
      frustration: Math.min(100, prev.frustration + (isWrongLine ? 1.0 : 0.1)),
      fear: Math.min(100, prev.fear + (isWrongLine ? 0.5 : 0))
    }));

    audio.playStep();
    const moveAmount = (stats.stamina / 100) * (isWrongLine ? 0.3 : 1.8);
    setPlayerPosition(prev => Math.min(100, prev + moveAmount));
  }, [stats.stamina, isVipPassing, isWrongLine]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === ' ') handleMove();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleMove]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 0) {
          clearInterval(interval);
          onFail();
          return 0;
        }
        if (prev < 25) setRainIntensity(Math.min(1, 0.4 + (25 - prev) / 25));
        return prev - 0.1;
      });

      setStats(prev => ({
        ...prev,
        frustration: Math.min(100, prev.frustration + 0.04),
        fear: Math.min(100, prev.fear + (isVipPassing ? 0.6 : 0.01))
      }));

      if (Math.random() < 0.008 && !isVipPassing && playerPosition > 10 && playerPosition < 85) triggerVip();
      
      if (Math.random() < 0.02 && !announcement) {
        const dice = Math.random();
        let text = "";
        let role: CharacterRole = "passenger_male";
        
        if (dice < 0.7) {
          const roleDice = Math.random();
          role = roleDice < 0.4 ? "passenger_male" : roleDice < 0.8 ? "passenger_female" : "system";
          text = BENGALI_STRINGS.npc_shouts[Math.floor(Math.random() * BENGALI_STRINGS.npc_shouts.length)];
        } else {
          role = "broker";
          text = BENGALI_STRINGS.broker_shouts[Math.floor(Math.random() * BENGALI_STRINGS.broker_shouts.length)];
        }
        setSpeakerType(role);
        setAnnouncement(text);
        audio.speak(text, role);
        setTimeout(() => setAnnouncement(""), 3500);
      }

      if (Math.random() < 0.005) {
        setIsWrongLine(prev => {
          if (!prev) audio.playAlarm();
          return !prev;
        });
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isVipPassing, onFail, playerPosition, announcement]);

  const triggerVip = () => {
    setIsVipPassing(true);
    setSpeakerType("vip");
    const text = BENGALI_STRINGS.vip_shouts[Math.floor(Math.random() * BENGALI_STRINGS.vip_shouts.length)];
    setAnnouncement(text);
    audio.speak(text, "vip");
    setStats(prev => ({ ...prev, fear: Math.min(100, prev.fear + 15) }));
    audio.playAlarm();
    
    setTimeout(() => {
      setIsVipPassing(false);
      setAnnouncement("");
      setPlayerPosition(prev => Math.max(0, prev - 12)); 
    }, 4500);
  };

  const handleBribe = () => {
    audio.playClick();
    setPlayerPosition(prev => Math.min(100, prev + 25));
    setStats(prev => ({ 
      ...prev, 
      frustration: Math.min(100, prev.frustration + 25),
      stamina: Math.max(0, prev.stamina - 15)
    }));
    setSpeakerType("broker");
    const shout = "টাকা পাইছি, যান সামনে যান! কেউ জিগাইলে আমার নাম কইবেন।";
    setAnnouncement(shout);
    audio.speak(shout, "broker");
    setTimeout(() => setAnnouncement(""), 3000);
  };

  useEffect(() => {
    updateGlobalStats(stats);
    if (playerPosition >= 100) onComplete(stats, false);
  }, [stats, playerPosition, onComplete, updateGlobalStats]);

  return (
    <div className="relative h-screen w-full overflow-hidden bg-transparent flex flex-col items-center justify-center pt-24">
      <div className={`absolute inset-0 transition-all duration-1000 ${isVipPassing ? 'bg-red-950/20' : isWrongLine ? 'bg-orange-950/10' : 'bg-transparent'}`} />
      
      <DynamicCrowd isVipPassing={isVipPassing} rainIntensity={rainIntensity} />
      <RainCanvas intensity={rainIntensity} />
      
      <AnimatePresence>
        {isVipPassing && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            className="absolute top-32 z-50 bg-gradient-to-r from-red-600 to-red-900 text-white px-8 py-3 rounded-2xl flex items-center gap-4 border border-red-500/50 shadow-[0_10px_40px_rgba(220,38,38,0.4)]"
          >
            <Siren className="animate-pulse w-6 h-6" />
            <span className="font-black uppercase tracking-[0.3em] text-xs">VIP PRIORITY MOVEMENT</span>
            <Siren className="animate-pulse w-6 h-6" />
          </motion.div>
        )}

        {announcement && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, x: 30 }} 
            animate={{ 
              opacity: 1, 
              scale: 1, 
              x: Math.random() * 40 - 20, 
              y: Math.random() * 20 - 10 
            }} 
            exit={{ opacity: 0, scale: 0.9 }}
            className={`absolute right-12 top-48 z-[100] px-6 py-4 rounded-3xl shadow-2xl backdrop-blur-3xl border ${
              speakerType === 'vip' ? 'bg-red-950/80 border-red-500/50 text-white' : 
              speakerType === 'broker' ? 'bg-yellow-500/90 border-yellow-400 text-black' :
              speakerType === 'system' ? 'bg-blue-600/90 border-blue-400 text-white' :
              'bg-slate-900/90 border-blue-500/20 text-blue-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
               <MessageCircle size={14} className="opacity-50" />
               <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
                 {speakerType === 'vip' ? 'URGENT' : speakerType === 'broker' ? 'BROKER' : speakerType === 'passenger_female' ? 'PASSENGER (F)' : speakerType === 'system' ? 'POLICE' : 'PASSENGER (M)'}
               </span>
            </div>
            <p className="font-black text-sm tracking-tight leading-tight">{announcement}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative w-full max-w-6xl h-80 bg-gradient-to-b from-slate-900/60 to-black/80 border border-blue-500/10 flex items-end justify-center pb-12 overflow-hidden rounded-[4rem] shadow-[0_30px_100px_rgba(0,0,0,0.8)]">
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-slate-900/90 backdrop-blur-md border-l-2 border-yellow-500/30 flex flex-col items-center justify-center p-6">
           <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-700 rounded-2xl flex items-center justify-center shadow-[0_0_40px_rgba(234,179,8,0.4)] mb-4">
             <Ticket className="text-black w-8 h-8" />
           </div>
           <span className="text-yellow-500 text-[10px] font-black uppercase tracking-[0.5em] rotate-90 whitespace-nowrap">TICKET DESK</span>
        </div>

        <motion.div 
          className="absolute z-40 bottom-12"
          animate={{ left: `${playerPosition}%`, y: [0, -3, 0], rotate: isWrongLine ? [0, 8, -8, 0] : 0 }}
          transition={{ left: { type: 'spring', damping: 20, stiffness: 100 }, y: { repeat: Infinity, duration: 0.5 } }}
        >
          <div className="relative flex flex-col items-center">
            <div className={`absolute -inset-8 rounded-full blur-3xl transition-all duration-700 ${isWrongLine ? 'bg-red-500/40' : 'bg-blue-500/10'}`} />
            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center shadow-2xl border-2 transition-all duration-300 ${isWrongLine ? 'bg-red-50 border-red-600 rotate-12' : 'bg-white border-white/20'}`}>
              <Users className={`${isWrongLine ? 'text-red-600' : 'text-slate-800'} w-8 h-8`} />
            </div>
            <div className={`w-3 transition-colors duration-300 rounded-b-full h-12 ${isWrongLine ? 'bg-red-600' : 'bg-white/40'}`} />
            <span className={`mt-3 text-[10px] font-black px-3 py-1 rounded-full shadow-xl uppercase tracking-widest ${isWrongLine ? 'bg-red-600 text-white' : 'bg-white text-black'}`}>
              PLAYER
            </span>
          </div>
        </motion.div>
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-slate-800/20 to-transparent pointer-events-none" />
      </div>

      <div className="mt-12 w-full max-w-xl flex flex-col items-center gap-8 px-4 z-30">
        <div className="flex gap-6 w-full">
          <motion.button 
            whileHover={{ scale: 1.05, translateY: -5 }} whileTap={{ scale: 0.95 }}
            onClick={handleMove}
            disabled={stats.stamina <= 0 || isVipPassing}
            className={`flex-[3] font-black py-6 rounded-3xl shadow-2xl transition-all text-xl uppercase tracking-[0.2em] border-b-8 ${
              isWrongLine ? 'bg-gradient-to-r from-red-600 to-red-800 text-white border-red-950' : 'bg-gradient-to-r from-white via-blue-50 to-blue-200 text-slate-900 border-blue-300'
            }`}
          >
            {isWrongLine ? 'FIX POSITION' : 'PUSH FORWARD'}
          </motion.button>
          
          <motion.button 
            whileHover={{ scale: 1.1, rotate: 2 }} whileTap={{ scale: 0.9 }}
            onClick={handleBribe}
            className="flex-1 bg-gradient-to-br from-yellow-400 to-yellow-600 text-black font-black px-6 py-6 rounded-3xl shadow-[0_10px_30px_rgba(234,179,8,0.3)] transition-all flex flex-col items-center justify-center gap-2 uppercase text-[10px]"
          >
            <AlertTriangle size={24} />
            BRIBE
          </motion.button>
        </div>
      </div>
    </div>
  );
};
