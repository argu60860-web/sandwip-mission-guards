
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { GameMetrics, PlayerStats } from '../types';
import { BENGALI_STRINGS } from '../constants';
import { RotateCcw, Frown, LogOut, MapPin, CheckCircle } from 'lucide-react';
import { audio } from '../audioUtils';

interface ResultScreenProps {
  metrics: GameMetrics;
  stats: PlayerStats;
  onRestart: () => void;
  onHome: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({ metrics, stats, onRestart, onHome }) => {
  useEffect(() => {
    if (metrics.survived) {
      // Narrate the success message
      const speech = `${BENGALI_STRINGS.success_msg}. ${BENGALI_STRINGS.successful_return}`;
      audio.speak(speech, "system");
    } else {
      audio.speak("যাত্রাটি ব্যর্থ হয়েছে। ঘাট কাউকে ক্ষমা করে না।", "system");
    }
  }, [metrics.survived]);

  const getEnding = () => {
    if (!metrics.survived) return {
      mainHeader: "যাত্রাটি ব্যর্থ হয়েছে",
      subHeader: "The Ghat has claimed another soul.",
      title: "ঘাট কাউকে ক্ষমা করে না",
      subtitle: "আপনি সন্দ্বীপে পৌঁছাতে পারেননি। হার মেনে নেওয়াও এক ধরণের সংগ্রাম।",
      icon: <Frown className="w-32 h-32 text-red-500" />,
      color: "from-red-400 to-red-700",
      glow: "shadow-[0_0_80px_rgba(220,38,38,0.3)]"
    };
    
    // Performance Based Message
    let perfMsg = "";
    let perfTitle = "";
    if (stats.fear < 30 && stats.frustration < 30) {
      perfTitle = "Strong Survivor Ending";
      perfMsg = "আপনি সন্দ্বীপের একজন প্রকৃত সাহসী যাত্রী। আপনার ধৈর্য্য অতুলনীয়।";
    } else {
      perfTitle = "Weak but Alive Ending";
      perfMsg = "আপনি ফিরেছেন, কিন্তু মানসিক ক্ষত রয়েই গেল। আপনি পরিশ্রান্ত।";
    }

    return {
      mainHeader: BENGALI_STRINGS.success_msg,
      subHeader: BENGALI_STRINGS.successful_return,
      title: perfTitle,
      subtitle: perfMsg,
      icon: <MapPin className="w-40 h-40 text-blue-400 animate-bounce" />,
      color: "from-blue-400 to-indigo-600",
      glow: "shadow-[0_0_120px_rgba(59,130,246,0.4)]"
    };
  };

  const ending = getEnding();

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#020617] p-6 overflow-y-auto">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-blue-900/30 via-slate-950 to-black pointer-events-none" />
      
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }}
        className={`w-full max-w-5xl bg-slate-900/40 backdrop-blur-3xl border border-blue-500/30 p-12 md:p-24 rounded-[5rem] text-center space-y-16 shadow-2xl relative overflow-hidden my-8 ${ending.glow}`}
      >
        <div className="absolute top-0 inset-x-0 h-3 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-50" />

        <div className="space-y-10">
          <motion.div 
            initial={{ y: 20 }} animate={{ y: 0 }}
            className="flex justify-center mb-6"
          >
            {ending.icon}
          </motion.div>
          <div className="space-y-6">
            <h1 className={`text-7xl md:text-9xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-b ${ending.color} leading-tight`}>
              {ending.mainHeader}
            </h1>
            <div className="flex flex-col gap-4">
               <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-widest">{ending.subHeader}</h2>
               <div className="flex items-center justify-center gap-4 text-blue-400 font-bold text-xl">
                 <CheckCircle size={24} />
                 <span>{ending.title}</span>
               </div>
               <p className="text-slate-300 text-xl md:text-2xl font-black max-w-3xl mx-auto italic leading-relaxed tracking-tight">
                 "{ending.subtitle}"
               </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
           {[
             { label: "Journey Time", val: `${metrics.timeElapsed.toFixed(1)}s` },
             { label: "Moral Bribes", val: metrics.bribesTaken > 0 ? "YES" : "NONE" },
             { label: "Mental Stress", val: `${Math.floor(stats.frustration)}%` },
             { label: "Fear Level", val: `${Math.floor(stats.fear)}%` }
           ].map((item, i) => (
             <motion.div 
               key={i} 
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.3 + (i * 0.1) }}
               className="bg-black/70 p-10 rounded-[3rem] border border-blue-500/20 flex flex-col items-center justify-center gap-3 shadow-inner group hover:border-blue-500/50 transition-all"
             >
               <span className="text-slate-500 text-xs font-black uppercase tracking-[0.3em] group-hover:text-blue-400 transition-colors">{item.label}</span>
               <span className="text-3xl font-mono font-black text-white">{item.val}</span>
             </motion.div>
           ))}
        </div>

        <div className="pt-10 flex flex-col md:flex-row gap-10">
          <button 
            onClick={onRestart}
            className="flex-[2] bg-gradient-to-br from-white via-blue-100 to-blue-200 text-black font-black py-10 rounded-[3rem] flex items-center justify-center gap-6 text-3xl hover:scale-105 active:scale-95 transition-all shadow-[0_30px_60px_rgba(59,130,246,0.3)] border-b-[12px] border-slate-300"
          >
            <RotateCcw size={40} /> TRY AGAIN
          </button>
          <button 
            onClick={onHome}
            className="flex-1 bg-slate-950/80 backdrop-blur-md text-white font-black py-10 rounded-[3rem] flex items-center justify-center gap-6 border-2 border-white/20 hover:bg-slate-800 transition-all text-2xl"
          >
            <LogOut size={32} /> HOME
          </button>
        </div>

        <div className="pt-6">
          <p className="text-slate-600 text-sm font-black uppercase tracking-[0.8em] leading-relaxed max-w-xl mx-auto opacity-60">
            “ভাই, এটা খেলতে গিয়ে মাথা নষ্ট হয়ে গেছে… কিন্তু এটা আমাদের গল্প।”
          </p>
        </div>
      </motion.div>
    </div>
  );
};
