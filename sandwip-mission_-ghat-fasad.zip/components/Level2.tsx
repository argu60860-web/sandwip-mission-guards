
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PlayerStats } from '../types';
import { BENGALI_STRINGS, LEVEL_TIMEOUTS } from '../constants';
import { Footprints, Ship, UserPlus, MessageSquare, AlertCircle, Waves } from 'lucide-react';
import { audio, CharacterRole } from '../audioUtils';

interface Level2Props {
  onComplete: (stats: PlayerStats) => void;
  onFail: () => void;
  updateGlobalStats: (stats: PlayerStats) => void;
  initialStats: PlayerStats;
}

const SeaBackground: React.FC = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
    <div className="absolute bottom-0 w-[200%] h-40 bg-gradient-to-t from-blue-900/40 to-transparent animate-wave">
      <svg className="w-full h-full opacity-30" viewBox="0 0 1000 100" preserveAspectRatio="none">
        <path d="M0,50 C150,100 350,0 500,50 C650,100 850,0 1000,50 L1000,100 L0,100 Z" fill="#1e3a8a" />
      </svg>
    </div>
    <div className="absolute bottom-4 w-[200%] h-32 bg-gradient-to-t from-blue-800/20 to-transparent animate-wave" style={{ animationDelay: '-5s' }}>
      <svg className="w-full h-full opacity-20" viewBox="0 0 1000 100" preserveAspectRatio="none">
        <path d="M0,50 C150,0 350,100 500,50 C650,0 850,100 1000,50 L1000,100 L0,100 Z" fill="#1d4ed8" />
      </svg>
    </div>
  </div>
);

const StrugglingNPCs: React.FC = () => {
  const npcs = useMemo(() => 
    Array.from({ length: 8 }).map((_, i) => ({
      id: i,
      x: 10 + Math.random() * 80,
      y: Math.random() * 20 - 10,
      scale: 0.8 + Math.random() * 0.3,
      delay: Math.random() * 5,
    })), []);

  return (
    <div className="absolute inset-0 pointer-events-none">
      {npcs.map((n) => (
        <motion.div
          key={n.id}
          className="absolute z-10"
          style={{ left: `${n.x}%`, bottom: `calc(3rem + ${n.y}px)` }}
          animate={{
            y: [0, -4, 0],
            rotate: [-2, 2, -2],
          }}
          transition={{
            duration: 2 + Math.random(),
            repeat: Infinity,
            delay: n.delay,
          }}
        >
          <div className="flex flex-col items-center opacity-40">
            <div className="w-10 h-10 rounded-full bg-stone-800 border-2 border-stone-700 flex items-center justify-center">
              <Footprints className="text-stone-600 w-5 h-5" />
            </div>
            <div className="w-2 h-12 bg-stone-800/60 rounded-b-full" />
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export const Level2: React.FC<Level2Props> = ({ onComplete, onFail, updateGlobalStats, initialStats }) => {
  const [distance, setDistance] = useState(0); 
  const [timer, setTimer] = useState(LEVEL_TIMEOUTS.LEVEL_2);
  const [stats, setStats] = useState<PlayerStats>(initialStats);
  const [isStuck, setIsStuck] = useState(false);
  const [stuckProgress, setStuckProgress] = useState(0);
  const [dialogue, setDialogue] = useState("");
  const [speaker, setSpeaker] = useState<CharacterRole>("boatman");

  const REQUIRED_STRUGGLE_CLICKS = 4;

  useEffect(() => {
    // Intro narration: "We've reached the river/ghat. What now?"
    audio.speak(BENGALI_STRINGS.level_intros.level2, "passenger_male");
  }, []);

  useEffect(() => { updateGlobalStats(stats); }, [stats, updateGlobalStats]);

  useEffect(() => {
    const tick = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 0) {
          clearInterval(tick);
          onFail();
          return 0;
        }
        return prev - 0.1;
      });

      setStats((prev) => ({
        ...prev,
        fear: Math.min(100, prev.fear + 0.08),
        frustration: Math.min(100, prev.frustration + 0.03)
      }));

      if (!isStuck && distance > 5 && distance < 88 && Math.random() < 0.01) {
        setIsStuck(true);
        setStuckProgress(0);
        audio.playAlarm();
        // Use the first shout: "Oh my god, I'm stuck in the mud"
        const stuckText = BENGALI_STRINGS.stuck_shouts[0];
        setSpeaker("passenger_male");
        setDialogue(stuckText);
        audio.speak(stuckText, "passenger_male");
        setTimeout(() => setDialogue(""), 3000);
      }

      if (Math.random() < 0.01 && !dialogue) {
        const rand = Math.random();
        let text = "";
        let role: CharacterRole = "boatman";
        
        if (rand < 0.7) {
          role = "boatman";
          text = BENGALI_STRINGS.porter_shouts[Math.floor(Math.random() * BENGALI_STRINGS.porter_shouts.length)];
        } else {
          role = Math.random() > 0.5 ? "passenger_male" : "passenger_female";
          text = BENGALI_STRINGS.porter_shouts[2] || "হায় খোদা!";
        }
        setSpeaker(role);
        setDialogue(text);
        audio.speak(text, role);
        setTimeout(() => setDialogue(""), 4500);
      }
    }, 100);

    return () => clearInterval(tick);
  }, [isStuck, distance, onFail, dialogue]);

  const handleEscapeMud = () => {
    const nextProgress = stuckProgress + 1;
    audio.playStruggle();
    if (nextProgress >= REQUIRED_STRUGGLE_CLICKS) {
      setIsStuck(false);
      setStuckProgress(0);
      setStats(prev => ({ 
        ...prev, 
        stamina: Math.max(0, prev.stamina - 2.5),
        frustration: Math.min(100, prev.frustration + 1)
      }));
    } else setStuckProgress(nextProgress);
  };

  const handleMovement = useCallback(() => {
    if (isStuck || stats.stamina <= 0) return;
    audio.playStep(true);
    const moveAmount = (stats.stamina / 100) * 1.6;
    setStats(prev => ({ ...prev, stamina: Math.max(0, prev.stamina - 0.2) }));
    setDistance(prev => {
      const next = prev + moveAmount;
      if (next >= 100) {
        onComplete(stats);
        return 100;
      }
      return next;
    });
  }, [isStuck, stats.stamina, onComplete, stats]);

  const handleHireHelp = () => {
    audio.playHelpingHand();
    setDistance(prev => Math.min(100, prev + 25));
    setStats(prev => ({
      ...prev,
      frustration: Math.min(100, prev.frustration + 10),
      stamina: Math.max(0, prev.stamina - 4)
    }));
    setIsStuck(false);
    setSpeaker("boatman");
    const shout = "মামা, ১০০ টাকা দেন, স্পিডবোটে উঠায়া দিমু।";
    setDialogue(shout);
    audio.speak(shout, "boatman");
    setTimeout(() => setDialogue(""), 3500);
  };

  return (
    <div className="relative h-screen w-full overflow-hidden bg-transparent flex flex-col items-center justify-center pt-24">
      <SeaBackground />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-stone-900/40 to-stone-950 pointer-events-none" />
      
      <AnimatePresence>
        {dialogue && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, x: -30 }} animate={{ opacity: 1, scale: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }}
            className={`absolute left-12 top-48 z-[100] p-6 rounded-3xl shadow-2xl backdrop-blur-3xl border ${
              speaker === 'boatman' ? 'bg-orange-950/80 border-orange-500/30 text-white' : speaker === 'passenger_female' ? 'bg-pink-950/80 border-pink-500/30 text-white' : 'bg-blue-950/80 border-blue-500/30 text-white'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare size={14} className="opacity-50" />
              <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
                {speaker === 'boatman' ? 'BOATMAN' : speaker === 'passenger_female' ? 'PASSENGER (F)' : 'PASSENGER (M)'}
              </span>
            </div>
            <p className="font-bold text-sm leading-tight italic">"{dialogue}"</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative w-full max-w-6xl h-80 bg-gradient-to-b from-stone-800/40 to-stone-900/60 border border-white/10 flex items-end justify-center pb-12 overflow-hidden rounded-[4rem] shadow-2xl">
        <div className="absolute inset-0 mud-texture opacity-90 z-0" />
        <div className="absolute right-0 top-0 bottom-0 w-36 bg-stone-900/90 backdrop-blur-md border-l-2 border-blue-500/20 z-20 flex flex-col items-center justify-center p-6">
           <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-900 rounded-2xl flex items-center justify-center shadow-[0_0_40px_rgba(59,130,246,0.3)] mb-4">
             <Ship className="text-white w-8 h-8" />
           </div>
           <span className="text-blue-400 text-[10px] font-black uppercase tracking-[0.5em] rotate-90 whitespace-nowrap">DOCKING AREA</span>
        </div>

        <StrugglingNPCs />

        <motion.div 
          className="absolute z-40 bottom-12"
          animate={{ left: `${distance}%`, y: isStuck ? [0, -2, 0] : [0, -5, 0] }}
          transition={{ left: { type: 'spring', damping: 20 }, y: { repeat: Infinity, duration: 0.6 } }}
        >
          <div className="relative flex flex-col items-center">
            <div className={`absolute -inset-8 rounded-full blur-3xl transition-all duration-700 ${isStuck ? 'bg-orange-500/40' : 'bg-blue-500/20'}`} />
            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center shadow-2xl border-2 transition-all duration-300 ${isStuck ? 'border-orange-600 bg-orange-100 scale-110' : 'bg-white border-white/40'}`}>
              <Footprints className={`${isStuck ? 'text-orange-600' : 'text-stone-800'} w-8 h-8`} />
            </div>
            <div className={`w-4 transition-all duration-300 rounded-b-full h-12 ${isStuck ? 'bg-orange-800' : 'bg-white/60'}`} />
            <span className={`mt-3 text-[10px] font-black px-3 py-1 rounded-full shadow-xl uppercase tracking-widest ${isStuck ? 'bg-orange-600 text-white' : 'bg-white text-black'}`}>YOU (PLAYER)</span>
            
            {isStuck && (
              <motion.div 
                initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}
                className="absolute -top-16 bg-gradient-to-r from-orange-600 to-red-600 text-white text-[10px] px-4 py-2 rounded-full font-black flex items-center gap-2 shadow-2xl border border-white/20 whitespace-nowrap uppercase tracking-wider"
              >
                <AlertCircle size={14} /> পা আটকে গেছে!
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>

      <div className="mt-12 w-full max-w-xl flex flex-col items-center gap-8 px-4 z-30">
        <div className="flex gap-6 w-full">
          <motion.button 
            whileHover={{ scale: 1.05, translateY: -5 }} whileTap={{ scale: 0.95 }}
            onClick={isStuck ? handleEscapeMud : handleMovement}
            disabled={stats.stamina <= 0}
            className={`flex-[3] font-black py-6 rounded-3xl shadow-2xl transition-all text-xl uppercase tracking-[0.2em] border-b-8 ${
              isStuck 
              ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white border-red-950' 
              : 'bg-gradient-to-r from-white via-white to-stone-300 text-black border-stone-400'
            }`}
          >
            {isStuck ? `STRUGGLE (${REQUIRED_STRUGGLE_CLICKS - stuckProgress})` : 'STEP FORWARD'}
          </motion.button>
          
          <motion.button 
            whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
            onClick={handleHireHelp}
            className="flex-1 bg-gradient-to-br from-blue-600 to-indigo-800 text-white font-black px-6 py-6 rounded-3xl shadow-2xl transition-all flex flex-col items-center justify-center gap-2 uppercase text-[10px] border-b-8 border-indigo-950"
          >
            <UserPlus size={24} />
            HIRE HELP
          </motion.button>
        </div>
      </div>
    </div>
  );
};
