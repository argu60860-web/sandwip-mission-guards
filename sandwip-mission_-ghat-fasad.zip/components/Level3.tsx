
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PlayerStats } from '../types';
import { BENGALI_STRINGS, LEVEL_TIMEOUTS } from '../constants';
import { Zap, AlertTriangle, Waves, Anchor, MessageCircle, CloudRain } from 'lucide-react';
import { audio, CharacterRole } from '../audioUtils';

interface Level3Props {
  onComplete: (stats: PlayerStats) => void;
  onFail: () => void;
  updateGlobalStats: (stats: PlayerStats) => void;
  initialStats: PlayerStats;
  setDisableHome: (disabled: boolean) => void;
}

type WireColor = 'red' | 'blue' | 'yellow';

const HugeWaves: React.FC = () => (
  <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
    <motion.div 
      className="absolute bottom-[-10%] w-[300%] h-[120%] flex flex-col justify-end"
      animate={{ x: ["0%", "-50%", "0%"] }}
      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
    >
      {[0, 1, 2, 3].map((i) => (
        <motion.div
          key={i}
          className="absolute bottom-0 w-full h-[60vh] opacity-40"
          style={{ bottom: `${i * 10}vh`, left: i % 2 === 0 ? '-10%' : '10%' }}
          animate={{ 
            y: [0, -30, 0],
            skewY: [0, 2, 0]
          }}
          transition={{ 
            duration: 4 + i, 
            repeat: Infinity, 
            delay: i * 0.5 
          }}
        >
          <svg className="w-full h-full" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path d="M0,50 C150,150 350,-50 500,50 C650,150 850,-50 1000,50 L1000,100 L0,100 Z" fill={i === 0 ? "#0c4a6e" : i === 1 ? "#075985" : "#0369a1"} />
          </svg>
        </motion.div>
      ))}
    </motion.div>
  </div>
);

const BoatVisualization: React.FC<{ isCrisis: boolean }> = ({ isCrisis }) => {
  return (
    <motion.div 
      className="relative z-10 w-full max-w-lg mb-8"
      animate={{ 
        rotate: isCrisis ? [-8, 8, -8] : [-2, 2, -2],
        y: isCrisis ? [0, -40, 0] : [0, -10, 0]
      }}
      transition={{ duration: isCrisis ? 1.2 : 3, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="absolute top-[-30px] left-[20%] right-[20%] h-12 flex justify-around items-end">
        {[0, 1, 2, 3, 4].map((i) => (
          <motion.div
            key={i}
            className="w-4 h-8 bg-black rounded-t-full opacity-80"
            animate={isCrisis ? { 
              y: [0, -15, 0], 
              rotate: [-10, 10, -10],
              scale: [1, 1.2, 1] 
            } : {}}
            transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.1 }}
          />
        ))}
      </div>

      <div className="relative h-24 w-full bg-stone-900 rounded-b-[40%] rounded-tr-[100%] rounded-tl-[10%] shadow-2xl border-t-4 border-stone-800">
        <div className="absolute top-0 right-10 w-16 h-8 bg-stone-800 rounded-t-lg -translate-y-full" />
        <div className="absolute top-0 left-10 w-4 h-12 bg-stone-700 -translate-y-full rotate-[-20deg]" />
        
        {isCrisis && (
          <motion.div 
            className="absolute top-0 right-12 w-12 h-12 bg-stone-400 blur-xl opacity-60 rounded-full"
            animate={{ y: -100, x: [0, 50, 0], scale: [1, 3, 1], opacity: [0.6, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </div>
    </motion.div>
  );
};

export const Level3: React.FC<Level3Props> = ({ onComplete, onFail, updateGlobalStats, initialStats, setDisableHome }) => {
  const [timer, setTimer] = useState(LEVEL_TIMEOUTS.LEVEL_3);
  const [stats, setStats] = useState<PlayerStats>(initialStats);
  const [engineState, setEngineState] = useState<'running' | 'smoking' | 'stopped'>('running');
  const [wires, setWires] = useState<WireColor[]>([]);
  const [targetWire, setTargetWire] = useState<WireColor | null>(null);
  const [dialogue, setDialogue] = useState("");
  const [speakerRole, setSpeakerRole] = useState<CharacterRole>("passenger_male");

  useEffect(() => {
    // Intro narration
    audio.speak(BENGALI_STRINGS.level_intros.level3, "passenger_female");
  }, []);

  useEffect(() => {
    const colors: WireColor[] = ['red', 'blue', 'yellow'];
    const shuffled = [...colors].sort(() => Math.random() - 0.5);
    setWires(shuffled);
    setTargetWire(colors[Math.floor(Math.random() * colors.length)]);
    setDisableHome(false);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 0) {
          clearInterval(interval);
          onFail();
          return 0;
        }
        return prev - 0.1;
      });

      if (timer < 25 && engineState === 'running') {
        setEngineState('smoking');
        triggerCry(0);
      }
      if (timer < 18 && engineState === 'smoking') {
        triggerCry(1);
      }
      if (timer < 10 && engineState === 'smoking') {
        setEngineState('stopped');
        setDisableHome(true);
        triggerCry(2);
      }

      setStats(prev => ({
        ...prev,
        fear: Math.min(100, prev.fear + (engineState === 'stopped' ? 1.5 : 0.4)),
        frustration: Math.min(100, prev.frustration + 0.15)
      }));
    }, 100);

    return () => clearInterval(interval);
  }, [engineState, timer, onFail, setDisableHome]);

  const triggerCry = (index: number) => {
    const text = BENGALI_STRINGS.storm_cries[index];
    setDialogue(text);
    const roles: CharacterRole[] = ["passenger_female", "passenger_male", "passenger_female"];
    const role = roles[index];
    setSpeakerRole(role);
    audio.speak(text, role);
    setTimeout(() => setDialogue(""), 6000);
  };

  const handleWireClick = (color: WireColor) => {
    audio.playClick();
    if (color === targetWire) {
      setDisableHome(false);
      onComplete(stats);
    } else {
      audio.playAlarm();
      onFail(); 
    }
  };

  useEffect(() => {
    updateGlobalStats(stats);
  }, [stats, updateGlobalStats]);

  return (
    <div className="relative h-screen w-full overflow-hidden bg-transparent flex flex-col items-center justify-center pt-24">
      <HugeWaves />
      
      {(Math.random() < 0.03 || engineState === 'stopped' && Math.random() < 0.1) && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 0.1 }}
          className="absolute inset-0 bg-white/20 z-50 pointer-events-none"
        />
      )}

      <div className="absolute inset-0 z-40 pointer-events-none opacity-40">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/10 to-transparent" />
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-white/40 w-px h-24"
            style={{ left: `${Math.random() * 100}%`, top: '-10%' }}
            animate={{ y: '110vh' }}
            transition={{ duration: 0.5 + Math.random(), repeat: Infinity, delay: Math.random() }}
          />
        ))}
      </div>

      <AnimatePresence>
        {dialogue && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}
            className={`absolute top-36 z-[100] px-10 py-6 rounded-[2.5rem] ${speakerRole === 'passenger_female' ? 'bg-pink-950/90 border-pink-500/50' : 'bg-red-950/90 border-red-500/50'} text-white shadow-[0_0_60px_rgba(220,38,38,0.5)] max-w-xl text-center`}
          >
            <MessageCircle className="mx-auto mb-2 text-red-400" />
            <p className="font-black text-xl md:text-2xl leading-tight italic tracking-tight">"{dialogue}"</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative z-10 w-full max-w-2xl px-4 flex flex-col items-center">
        
        <BoatVisualization isCrisis={engineState !== 'running'} />

        <div className="text-center space-y-4 mb-8">
          <motion.div 
            animate={{ scale: engineState === 'stopped' ? [1, 1.2, 1] : 1 }}
            transition={{ repeat: Infinity, duration: 1 }}
          >
            <AlertTriangle className={`w-20 h-20 mx-auto ${engineState === 'stopped' ? 'text-red-500' : 'text-yellow-500'}`} />
          </motion.div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tighter">
            {engineState === 'stopped' ? "ইঞ্জিন বিকল! ডুবে যাচ্ছেন!" : "ENGINE FAILURE IMMINENT"}
          </h1>
        </div>

        {engineState === 'stopped' && (
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-full bg-stone-900/90 backdrop-blur-3xl p-8 rounded-[3rem] border-4 border-stone-700 shadow-[0_0_100px_rgba(0,0,0,1)] relative overflow-hidden"
          >
             <div className="grid grid-cols-3 gap-6">
               {wires.map((color) => (
                 <button
                   key={color}
                   onClick={() => handleWireClick(color)}
                   className={`h-40 rounded-2xl relative transition-all active:scale-90 group border-4 border-black/40`}
                   style={{ backgroundColor: color }}
                 >
                   <div className="absolute inset-0 flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                     <Zap className="animate-pulse" />
                     <span className="font-black text-[10px] uppercase">CONNECT</span>
                   </div>
                   <div className="absolute top-0 bottom-0 left-1/2 w-2 bg-black/30" />
                 </button>
               ))}
             </div>
             <p className="mt-6 text-center text-red-400 font-black uppercase tracking-widest text-xs">
               RECONNECT THE {targetWire?.toUpperCase()} WIRE NOW!
             </p>
          </motion.div>
        )}

        <div className="mt-8 text-center space-y-2 opacity-60">
           <p className="text-xs italic text-stone-400">"মাঝ সমুদ্রে কেউ শোনে না কান্নার আওয়াজ"</p>
        </div>
      </div>

      {stats.fear > 70 && (
        <motion.div 
          animate={{ x: [-3, 3, -3], y: [2, -2, 2] }}
          transition={{ repeat: Infinity, duration: 0.05 }}
          className="absolute inset-0 pointer-events-none bg-red-950/5"
        />
      )}
    </div>
  );
};
