
import React from 'react';
import { motion } from 'framer-motion';
import { BENGALI_STRINGS } from '../constants';
import { Anchor, Play, BookOpen } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
  onDirectPlay: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ onStart, onDirectPlay }) => {
  return (
    <div className="relative h-screen w-full flex flex-col items-center justify-center bg-transparent overflow-hidden text-center p-6">
      {/* Dynamic Background Mesh */}
      <div className="absolute inset-0 opacity-40 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-blue-600/10 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-indigo-900/20 blur-[150px] rounded-full" />
      </div>
      
      <motion.div 
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="z-10 space-y-12 max-w-4xl"
      >
        <div className="space-y-4">
          <motion.h1 
            className="text-7xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-blue-50 to-stone-500 tracking-tighter leading-none"
            animate={{ filter: ["brightness(1)", "brightness(1.2)", "brightness(1)"] }}
            transition={{ repeat: Infinity, duration: 4 }}
          >
            {BENGALI_STRINGS.title}
          </motion.h1>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-12 bg-blue-900/50" />
            <p className="text-blue-300/60 font-black uppercase tracking-[0.6em] text-xs md:text-sm">
              {BENGALI_STRINGS.subtitle}
            </p>
            <div className="h-px w-12 bg-blue-900/50" />
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-slate-900/40 backdrop-blur-2xl border border-blue-500/10 p-10 rounded-[2.5rem] space-y-6 text-left shadow-2xl"
        >
          <p className="text-blue-50/80 text-xl md:text-2xl font-light leading-relaxed italic">
            "This is not a game about winning. It's about surviving the <span className="text-white font-bold underline decoration-blue-500/50">humiliation</span>, the <span className="text-stone-300 font-bold decoration-stone-500/50 underline">mud</span>, and the <span className="text-blue-400 font-bold decoration-blue-500/50 underline">sea</span>."
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
            {["No Hero Powers", "Real Stress", "Unfair Events", "Emotional Toll"].map((text, i) => (
              <div key={i} className="flex flex-col gap-1">
                <div className="h-1 w-8 bg-gradient-to-r from-blue-500 to-transparent rounded-full" />
                <span className="text-[10px] font-black text-blue-400/40 uppercase tracking-widest">{text}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
          <motion.button 
            whileHover={{ scale: 1.05, translateY: -5 }}
            whileTap={{ scale: 0.95 }}
            onClick={onDirectPlay}
            className="group relative inline-flex items-center justify-center px-12 py-6 font-black text-black transition-all bg-gradient-to-br from-white via-blue-50 to-blue-200 rounded-2xl shadow-[0_0_40px_rgba(59,130,246,0.15)] overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-3 text-xl uppercase tracking-[0.2em] font-black">
              <Play className="fill-current w-6 h-6" />
              {BENGALI_STRINGS.start_game}
            </span>
          </motion.button>

          <motion.button 
            whileHover={{ scale: 1.05, backgroundColor: "rgba(59,130,246,0.1)" }}
            whileTap={{ scale: 0.95 }}
            onClick={onStart}
            className="group relative inline-flex items-center justify-center px-12 py-6 font-black text-white transition-all bg-slate-900/50 backdrop-blur-md border border-blue-500/20 hover:border-blue-500/50 rounded-2xl overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-3 text-xl uppercase tracking-[0.2em] font-black text-blue-100">
              <BookOpen className="w-6 h-6" />
              {BENGALI_STRINGS.instructions_btn}
            </span>
          </motion.button>
        </div>
      </motion.div>

      <Anchor className="absolute -bottom-10 -right-10 text-blue-500/5 w-64 h-64 rotate-12" />
    </div>
  );
};
